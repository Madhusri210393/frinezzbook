/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Comments {
    private String User;
    private String UPid;
    private String Content;
    private String Date;

    public Comments(String User, String UPid, String Content, String Date) {
        this.User = User;
        this.UPid = UPid;
        this.Content = Content;
        this.Date = Date;
    }

    public String getUser() {
        return User;
    }

    public void setUser(String User) {
        this.User = User;
    }

    public String getUPid() {
        return UPid;
    }

    public void setUPid(String UPid) {
        this.UPid = UPid;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String Content) {
        this.Content = Content;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }
    
}

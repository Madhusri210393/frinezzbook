/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author HP
 */
@ManagedBean
@SessionScoped
public class Login implements Serializable{

    /**
     * Creates a new instance of Login
     */
        private  String AccountID="";
        private String Password="";
        private UserTimeLine thelogin;


    public String getAccountID() {
        return AccountID;
    }

    public void setAccountID(String AccountID) {
        this.AccountID = AccountID;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public UserTimeLine getThelogin() {
        return thelogin;
    }

    public void setThelogin(UserTimeLine thelogin) {
        this.thelogin = thelogin;
    }
    
        
    public String loginFriendsBookAccount()
    {       
        
        //access the database and then login
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
         try
        {
            Class.forName("com.mysql.jdbc.Driver");
            
        }
        catch (Exception e)
        {
            return ("error");
           
        }
        
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            //do a query to make sure Accountid and pasword is found
            rs=st.executeQuery("Select * from UserAccount where AccountID='"+AccountID+"'");
            if(rs.next()){
                if(Password.equals(rs.getString("Password")))
                {
                    //store userinformation in ur session class
                    thelogin= new UserTimeLine(AccountID, Password,rs.getString("Name"),rs.getString("Gender"),rs.getString("School"),rs.getString("Birthday"));
                    return"Mainmenu";
                }
                else
                {
                  return "loginNotOK";
                }
               
            }
            else
            {
               return "loginNotOK";
                 
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
           return "Errorreg";
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
              return "Errorreg";
            }
        }
    }
    
}

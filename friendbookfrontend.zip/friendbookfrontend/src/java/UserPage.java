/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author HP
 */
@ManagedBean(name="user")
@SessionScoped
public class UserPage {

    /**
     * Creates a new instance of UserPage
     */
    public UserPage() {
    }

    /**
     * Creates a new instance of UserTimeLine
     */
    private String accountid;
    private String password;
    private ArrayList<Notification> noti;
    private ArrayList<friends> fri;
    private ArrayList<notfriends> uf;
    private ArrayList<message> message;
    private ArrayList<users> user;
    private ArrayList<users> prof;
    private ArrayList<HashTag> hash;
    private ArrayList<Comments>comment;
    private ArrayList<UpdatePost>UP;
    private ArrayList<friendshash>Frin;
    private String Nid;
    private String Sender;
    private String type;
    private String Content;
    private String word;
    boolean notifound=false;
    private String id;
    private List<Notification> notifications;
    private String Name;
    private String Gender;
    private String School;
    private String Birthday;

    public ArrayList<UpdatePost> getUP() {
        return UP;
    }

    public void setUP(ArrayList<UpdatePost> UP) {
        this.UP = UP;
    }

 

    public ArrayList<Comments> getComment() {
        return comment;
    }

    public void setComment(ArrayList<Comments> comment) {
        this.comment = comment;
    }

    public ArrayList<friendshash> getFrin() {
        return Frin;
    }

    public void setFrin(ArrayList<friendshash> Frin) {
        this.Frin = Frin;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public ArrayList<HashTag> getHash() {
        return hash;
    }

    public void setHash(ArrayList<HashTag> hash) {
        this.hash = hash;
    }

    public ArrayList<users> getProf() {
        return prof;
    }

    public void setProf(ArrayList<users> prof) {
        this.prof = prof;
    }

    public String getSchool() {
        return School;
    }

    public void setSchool(String School) {
        this.School = School;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getBirthday() {
        return Birthday;
    }

    public void setBirthday(String Birthday) {
        this.Birthday = Birthday;
    }
    

    public ArrayList<notfriends> getUf() {
        return uf;
    }

    public void setUf(ArrayList<notfriends> uf) {
        this.uf = uf;
    }

 

    public ArrayList<users> getUser() {
        return user;
    }

    public void setUser(ArrayList<users> user) {
        this.user = user;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String Content) {
        this.Content = Content;
    }

    public ArrayList<message> getMessage() {
        return message;
    }

    public void setMessage(ArrayList<message> message) {
        this.message = message;
    }

    public ArrayList<friends> getFri() {
        return fri;
    }

    public void setFri(ArrayList<friends> fri) {
        this.fri = fri;
    }

     public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    public String getNid() {
        return Nid;
    }

    public void setNid(String Nid) {
        this.Nid = Nid;
    }

    public ArrayList<Notification> getNoti() {
        return noti;
    }

    public void setNoti(ArrayList<Notification> noti) {
        this.noti = noti;
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }
    
    
    public UserPage(String id,String pwd) {
        noti=new ArrayList<Notification>();
        fri=new ArrayList<friends>();
        user=new ArrayList<users>();
        uf=new ArrayList<notfriends>();
        accountid=id;
        
        //To search if User Notifications In Notification Database
           final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
         
         try
        {
            Class.forName("com.mysql.jdbc.Driver");
            
        }
        catch (Exception e)
        {
            System.out.println("This has an internal error");
           
        }
         
          try
        {
                conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673"); 
                //Create a Statement
                st=conn.createStatement();
                //do a query to find notifications from notification
                rs=st.executeQuery("Select * from Notification where Receiver='"+id+"'"+"and Status='Pending'");
                while (rs.next())
                {
                  noti.add(new Notification(rs.getString("NotID"),rs.getString("Sender"),rs.getString("Type"),rs.getString("Content"),rs.getString("Status")));
                    notifound=true;
                }
                rs=st.executeQuery("Select * from Friends where UserID1='"+accountid+"'or UserID2='"+accountid+"'");
                while (rs.next())
                {
                    if(rs.getString("UserID1").equals(accountid)){
                    fri.add(new friends(rs.getString("UserID2")));
                    notifound=true;
                    }
                    else if(rs.getString("UserID2").equals(accountid))
                  fri.add(new friends(rs.getString("UserID1")));
                    notifound=true;
                }
                rs=st.executeQuery("Select * from useraccount");
                   while (rs.next()) {
                       
                           if(!rs.getString("AccountID").equals(accountid)){
                            user.add(new users(rs.getString("AccountID"),rs.getString("Name"),rs.getString("Gender"),rs.getString("School"),rs.getString("Birthday")));
                             notifound=true;
                       }
//                    for(friends fr:fri)
//                    {
//                       for(users u:user){
//                           if(!fr.getUser().equals(u.getAid())){
//                              uf.add(new notfriends(u.getAid()));
//                           }
//                          
//                       }
//                    }
                }
            
        }
          catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
    public int count=0;
    public String Notification()
    {
        
      notifications= new ArrayList<Notification>();
        if(notifound){
            for(Notification not:noti){
               // notifications.add(not.getNid(),not.getSender(),not.getType(),not.getContent(),not.getStatus());
                notifications.add(not);
            }
            return "Notification";
        }
        else{
            return "errorlogin";
        }
    }
    public String acceptnotification(String Nid,String ty) {
        
            final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
         
         try
        {
                conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673"); 
                //Create a Statement
                st=conn.createStatement();
                //do a query to find notifications from notification
                if(ty.equals("Friend Request")){
                for(Notification notif:noti){
                        if(notif.getNid().equals(Nid)){
                            int a=st.executeUpdate("Update Notification set Status='Accepted',Content='Connected' where NotID='"+Nid+"'");
                            int b=st.executeUpdate("Insert into Friends values('"+accountid+"','"+notif.getSender()+"')");
                        }
                }
                return "thankyou";
        }
                else if(ty.equals("Message")){
                for(Notification notif:noti){
                        if(notif.getNid().equals(Nid)){
                        int a=st.executeUpdate("Update Notification set Status='Accepted' where NotID='"+Nid+"'");
                        }
                        
                    }
                return "message";
                }
                else{
                    return "error";
                }
                
                }
         catch(SQLException e)
            {
                e.printStackTrace();
                return"error";
            }
            finally
            {
                try
                {
                    conn.close();
                    st.close();
                    
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                    return"error";
                }

            }
            
    }
   public String rejectnotification(String Nid,String ty) {
            final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
         
         try
        {
                conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673"); 
                //Create a Statement
                st=conn.createStatement();
                //do a query to find notifications from notification
                if(ty.equals("Friend Request")){
                for(Notification notif:noti){
                        if(notif.getNid().equals(Nid)&& notif.getType().equals("Friend Request")){
                            int a=st.executeUpdate("Update Notification set Status='Rejected',Content='You have rejected the request' where NotID='"+Nid+"'");
                        }
                    }
                return "thankyou";
                }
                if(ty.equals("Message")){
                    for(Notification notif:noti){
                if(notif.getNid().equals(Nid)&& notif.getType().equals("Message")){
                        int a=st.executeUpdate("Update Notification set Status='Rejected' where NotID='"+Nid+"'");
                        }
                    }
                    return "Message";
                }
                else{
                    return "error";
                }
                
                }
         catch(SQLException e)
            {
                e.printStackTrace();
                return"error";
            }
            finally
            {
                try
                {
                    conn.close();
                    st.close();
                    
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                    return"error";
                }

            }
    }
   public String friends() {
       if(notifound){
           return "friends";
       }
       else{
           return"Nofriends";
       }
   }
    public String messagefri() {
       if(notifound){
           return "message";
       }
       else{
           return"Nofriends";
       }
   }
   public String message(String fid) {
       //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        id=fid;
        Connection conn=null;
        Statement st=null;
                
        
        ResultSet rs=null;
        message=new ArrayList<message>();
        
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            
            //do a query to Find Messages realted to userAccount
            rs=st.executeQuery("Select * from Notification where (Receiver='"+fid+"' and Sender='"+accountid+"'and Type='Message') or (Receiver='"+accountid+"'and Sender='"+fid+"'and Type='Message')");
           
            while(rs.next()){
                message.add(new message(rs.getString("Sender"),rs.getString("content"),rs.getString("Receiver")));
            }
                          return "messagedis";
           
        }
        catch(SQLException e)
        {
           e.printStackTrace();
           return"error";
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
                
            }
            catch(Exception e)
            {
              e.printStackTrace();
              return"error";
            }
        }
       
   }
   public String sendmessage(){
       //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        int NotID=0;
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            rs=st.executeQuery("Select *from nextnot");
            int nextNum=0;
            //update the nextNotification Number
            if(rs.next())
            {
               NotID=0+rs.getInt(1);
               nextNum=rs.getInt(1)+1;
            }
            //updates the next_id
                        int t=st.executeUpdate("Update nextnot set Next_id='"+nextNum+"'");
                        //instert into Notification table
                        int a=st.executeUpdate("Insert into Notification values('"+NotID+"','"+accountid+"','"+id+"','"+"Message"+"','"+Content+"','"+"Pending"+"')");
        return "msgconfirm";
        }
        catch(SQLException e)
        {
           e.printStackTrace();
           return "error";
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
                
            }
            catch(Exception e)
            {
              e.printStackTrace();
              return "error";
            }
        }
   }
   public String disfriendrequest(){ 
            return "friendreq";
   }
   public String sendrequest(String aid){
        int NotID=0;        
        //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        Statement st1=null;
        ResultSet rs1=null;
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            st1=conn.createStatement();
            //To get the Notification ID
            rs=st.executeQuery("Select *from nextnot");
            int nextNum=0;
            //update the nextNotification Number
            if(rs.next())
            {
               NotID=0+rs.getInt(1);
               nextNum=rs.getInt(1)+1;
            }
            rs1=st1.executeQuery("Select * from Friends where (UserID1='"+aid+"' and USerID2='"+accountid+"') or (UserID1='"+accountid+"' and UserID2='"+aid+"')");
                
            if(rs1.next()){
            return "alreadyfri";
            }
            else if(!rs1.next()){
            //updates the next_id
            int t=st.executeUpdate("Update nextnot set Next_id='"+nextNum+"'");
            //instert into Notification table
           int r=st.executeUpdate("Insert into Notification values('"+NotID+"','"+accountid+"','"+aid+"','"+"Friend Request"+"','"+"You Have New Friend Request"+"','"+"Pending"+"')");
           return "friendsent";
            }
            else{
                return "error";
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
           return "error";
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
                st1.close();
                rs1.close();
               
            }
            catch(Exception e)
            {
              e.printStackTrace();
              return "error";
            }
        }
   }
public String updateProfile()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            return ("Internal Error. Please Try It Again"+accountid+"hello");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from UserAccount where AccountID='"+accountid+"'");
            if (rs.next())
            {
                //update userAccount table if the user already exists in the userAccount table
                    st.executeUpdate("Update UserAccount set Name ='"+ Name
                                    +"', Password='" + password 
                                    +"', Gender='" + Gender 
                                    +"', School ='"+ School 
                                    +"', Birthday='"+ Birthday
                                    +"' where AccountID='"+accountid+"'");
            }           
//            else
//            {
//                //if the user has not been in the userAccount table, insert a new record to userAccount table 
//                st.executeUpdate("Insert into UserAccount values('"+AccountID+"','"+password+"','"+Name+"','"+Gender+"','"+School+"','"+ Birthday+"')");
//            }
                        
            //return a successful message
            return ("Your profile has been updated!!!");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error. Please Try It Again");
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return ("Internal Error. Please Try It Again");
            }
        }
        
    }
 public String viewprofile(String aid) {
     prof=new ArrayList<users>();
     try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            return ("Internal Error. Please Try It Again"+accountid+"hello");
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            st = conn.createStatement();
            rs = st.executeQuery("Select * from UserAccount where AccountID='"+aid+"'");
            if (rs.next())
            {
                prof.add(new users(rs.getString("AccountID"),rs.getString("Name"),rs.getString("Gender"),rs.getString("School"),rs.getString("Birthday")));
                return"viewprofile";
            }           
            else{
                return"notfound";
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return ("Internal Error. Please Try It Again");
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return ("Internal Error. Please Try It Again");
            }
        }

   } 
 public String hashtag(){
     hash=new ArrayList<HashTag>();
     //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        int cou=1;
         try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            
            ArrayList<HashTag>Has=new ArrayList<HashTag>();
            rs=st.executeQuery("Select * from HashTag order by Count desc");
            while(rs.next()){
                HashTag HT=new HashTag(rs.getString("Hashtag"),rs.getInt("Count"));
                Has.add(HT);
            }
            for(HashTag ht:Has){
                if(cou<=3){
                    hash.add(new HashTag(ht.getWord(),ht.getCount()));
                    cou++;
                }
            }
            return"hashtag";
            }
         catch(SQLException e)
        {
           e.printStackTrace();
           return"error";
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
              return "error";
            }
        }
 }
 public String searchtag(){
     //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        comment=new ArrayList<Comments>();
        UP=new ArrayList<UpdatePost>();
        Frin=new ArrayList<friendshash>();
        Connection conn=null;
        Statement st3=null;
        ResultSet rs3=null;
        Statement st1=null;
        ResultSet rs1=null;
        Statement st2=null;
        ResultSet rs2=null;
        int intIndex=0;
         try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st1=conn.createStatement();
            st1=conn.createStatement();
            st2=conn.createStatement();
            ArrayList<Comments>com=new ArrayList<Comments>();
            ArrayList<UpdatePost>upd=new ArrayList<UpdatePost>();
            ArrayList<friendshash>Fri=new ArrayList<friendshash>();
            
            //do a query to find friends from Friends
            rs1=st1.executeQuery("Select * from Friends where UserID1='"+accountid+"'"+"or UserID2='"+accountid+"'");
            //ArrayList for Friends
            while (rs1.next())
            {
              friendshash fr=new friendshash(rs1.getString("UserID1"),rs1.getString("UserID2"));
                Fri.add(fr);
            }

            //do a query to find Updates and posts from UpdatePost
            rs2=st2.executeQuery("Select * from Update_Post order by UPID desc");
            //ArrayList for UpdatePost
            while (rs2.next())
            {
               for(friendshash fri:Fri){
                   if(rs2.getString("UserID").equals(fri.getUser1())||rs2.getString("UserID").equals(fri.getUser2())){
                    UpdatePost UPo=new UpdatePost(rs2.getString("UPID"),rs2.getString("UserID"),rs2.getString("Type"),rs2.getString("Content"),rs2.getString("Date_Time"));
                    upd.add(UPo);
                   }
               }
            }

            //do a query to find Comments from Comments
            rs3=st3.executeQuery("Select * from Comments");
            while (rs3.next())
            {
              Comments Com=new Comments(rs3.getString("UserID"),rs3.getString("UPID"),rs3.getString("Content"),rs3.getString("Date"));
                com.add(Com);
            }
             for(UpdatePost UPs:upd){
                    if(!UPs.getUserID().equals(accountid)){
                        String msg=UPs.getContent().toLowerCase();
                        int Ash=word.indexOf("#");
                        intIndex = msg.indexOf(word); 
                        if(intIndex!=-1&&Ash!=-1){
                            UpdatePost UPo=new UpdatePost(rs2.getString("UPID"),rs2.getString("UserID"),rs2.getString("Type"),rs2.getString("Content"),rs2.getString("Date_Time"));
                            UP.add(UPo);
                        }
                        
                    }
                }
                return"hashtag";
            }
         catch(SQLException e)
        {
           e.printStackTrace();
           return "error";
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st1.close();
                rs1.close();
                st2.close();
                rs2.close();
                st3.close();
                rs3.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
              return "error";
            }
        }
        
    }
    public String getAccountid() {
        return accountid;
    }

    public void setAccountid(String accountid) {
        this.accountid = accountid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author HP
 */
@ManagedBean
//@RequestScoped
public class Notification {

    /**
     * Creates a new instance of Notification
     */
    private String Nid;
    private String Sender;
    private String type;
    private String Content;
    private String Status;
    public ArrayList<Notification> noti;
    private boolean found=false;
    public Notification(){
        
    }

    public Notification(String Nid, String Sender, String type, String Content, String Status) {
        this.Nid = Nid;
        this.Sender = Sender;
        this.type = type;
        this.Content = Content;
        this.Status = Status;
    }
 
   
    

    public String getNid() {
        return Nid;
    }

    public void setNid(String Nid) {
        this.Nid = Nid;
    }

    public String getSender() {
        return Sender;
    }

    public void setSender(String Sender) {
        this.Sender = Sender;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String Content) {
        this.Content = Content;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
   
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.faces.bean.ManagedBean;
import javax.faces.bean.NoneScoped;

/**
 *
 * @author HP
 */
@ManagedBean
@NoneScoped
public class friends {

    /**
     * Creates a new instance of friends
     */
    private String user;


    public friends(String user) {
        this.user = user;
    }


    public String getUser() {
        return user;
    }

    public void setUser(String user1) {
        this.user = user1;
    }

    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class friendshash {
    private String User1;
    private String User2;

    public friendshash(String User1, String User2) {
        this.User1 = User1;
        this.User2 = User2;
    }

    public String getUser1() {
        return User1;
    }

    public void setUser1(String User1) {
        this.User1 = User1;
    }

    public String getUser2() {
        return User2;
    }

    public void setUser2(String User2) {
        this.User2 = User2;
    }
}
